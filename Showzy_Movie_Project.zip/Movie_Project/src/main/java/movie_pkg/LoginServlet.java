package movie_pkg;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jdbc_pkg.*;

public class LoginServlet extends HttpServlet {
	
	//private static final long serialVersionUID = 1L;
		@Override
		protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			PrintWriter out = resp.getWriter();
			String user = req.getParameter("user");
			String pass = req.getParameter("password");
			
			User_module um = new User_module();
			String role = um.logUser(user,pass);
			if (role != null) {
		        HttpSession session = req.getSession();
		        session.setAttribute("isAuthenticated", true);
		        session.setAttribute("username", user);
		        session.setAttribute("role", role);

		        if (role.equalsIgnoreCase("admin")) {
		            resp.sendRedirect("admin.jsp");
		        } else {
		            resp.sendRedirect("main");
		        }
		    } else {
		        resp.setContentType("text/html");
		        out.println("<h2>Invalid Credentials</h2>");
		    }
						
		}
	}