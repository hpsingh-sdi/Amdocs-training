package movie_pkg;

import javax.servlet.*;
import javax.servlet.http.*;

import jdbc_pkg.Movie;
import jdbc_pkg.MovieDAO;

import java.io.IOException;
import java.util.List;

public class MainServlet extends HttpServlet {
    private MovieDAO movieDAO;

    public void init() {
        movieDAO = new MovieDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	HttpSession session = request.getSession(false); // don't create a new session
    	Boolean isAuthenticated = (session != null) ? (Boolean) session.getAttribute("isAuthenticated") : null;

    	if (isAuthenticated == null || !isAuthenticated) {
    	    response.sendRedirect("login.html");
    	    return;
    	}

    	//System.out.println(isAuthenticated);
 
    	String city = request.getParameter("city");
        String genre = request.getParameter("genre");
        String language = request.getParameter("language");
        String search = request.getParameter("search");

        // Trim inputs to avoid blank space issues
        city = (city != null && !city.trim().isEmpty()) ? city.trim() : null;
        genre = (genre != null && !genre.trim().isEmpty()) ? genre.trim() : null;
        language = (language != null && !language.trim().isEmpty()) ? language.trim() : null;
        search = (search != null && !search.trim().isEmpty()) ? search.trim() : null;

        List<Movie> movies = movieDAO.getFilteredMovies(city, genre, language, search);

        request.setAttribute("movies", movies);
        request.getRequestDispatcher("main.jsp").forward(request, response);

    }
}
