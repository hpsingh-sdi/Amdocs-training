package jdbc_pkg;

import java.sql.Connection; 
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException; 
import java.sql.Statement;

public class User_module {
	// JDBC URL, username and password of MySQL server
	private static final String url = "jdbc:mysql://localhost:3306/movie";
	private static final String user = "root";
	private static final String pwd = "riya";
	
	Connection con;
	PreparedStatement prSt;
	Statement stmt;
	
	public boolean regUser(String name, String password, String email, String phone) {
		String query = "Insert into users(username,password,email,phone) values(?,?,?,?)";
		
	      try {
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            con = DriverManager.getConnection(url, user, pwd);
	           
	            prSt = con.prepareStatement(query);
	            prSt.setString(1, name);
	            prSt.setString(2, password);
	            prSt.setString(3, email);
	            prSt.setString(4, phone);
	            int count = prSt.executeUpdate();
	            
	            if(count>0) {
	            	return true;
	            }
	      }
	      catch (ClassNotFoundException e) {
	    	  	e.printStackTrace();
	        } 
	      catch (SQLException e) {
	            e.printStackTrace();
	        } 
	      finally{
	            try{
	                if(prSt != null) prSt.close();
	                if(con != null) con.close();
	            } catch(Exception ex){}
	        }
	      return false;
	}
	
	public String logUser(String name, String pass) {
		String role = null;
	      try {
      	    	String query = "SELECT * FROM users WHERE username=? AND password = ?";
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            con = DriverManager.getConnection(url, user, pwd);
	           
	            prSt = con.prepareStatement(query);
	            prSt.setString(1, name);
	            prSt.setString(2, pass);
	            ResultSet rs = prSt.executeQuery();
	            
	            if (rs.next()) {
	                role = rs.getString("role"); // return role
	            }
	            return role;
	            
	      }
	      catch (ClassNotFoundException e) {
	    	  	e.printStackTrace();
	        } 
	      catch (SQLException e) {
	            e.printStackTrace();
	        } 
	      finally{
	            try{
	                if(prSt != null) prSt.close();
	                if(con != null) con.close();
	            } catch(Exception ex){}
	        }
	      return role;
	}

}
